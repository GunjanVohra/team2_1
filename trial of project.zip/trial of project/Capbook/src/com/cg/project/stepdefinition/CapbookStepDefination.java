package com.cg.project.stepdefinition;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;


import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class CapbookStepDefination {

	private WebDriver driver;

	private CapbookStepDefination pageBean;
	
	@Before
	public void setUpStepEnv() {
		System.setProperty("webdriver.chrome.driver",
				"F:\\chromedriver.exe" );
		driver=new ChromeDriver();	
	}
	
	